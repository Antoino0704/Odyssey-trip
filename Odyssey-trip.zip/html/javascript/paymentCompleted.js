$(document).ready(function() {
    $("#spinner").fadeOut(2000);
    setTimeout(() => document.body.style.backgroundImage = "url('https://www.yeastar.com/wp-content/uploads/2020/08/pay-step4.png')", 2000);
});